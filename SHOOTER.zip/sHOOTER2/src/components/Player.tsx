import { useEffect, useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { useKeyboardControls } from '@react-three/drei';
import { Vector3, Group, Quaternion } from 'three';
import { useGameStore } from '../store/gameStore';
import { Bullet } from './Bullet';
import { Weapon } from './Weapon';

const MOVEMENT_SPEED = 0.15;
const BULLET_SPEED = 1.0; // Slower bullet speed so it's more visible

export const Player = () => {
  const playerRef = useRef<Group>(null);
  const velocityRef = useRef(new Vector3());
  const [bullets, setBullets] = useState<{ id: number; position: Vector3; direction: Vector3 }[]>([]);
  const bulletIdCounter = useRef(0);
  const lastShootTime = useRef(0);
  
  const updatePlayerPosition = useGameStore((state) => state.updatePlayerPosition);
  const updatePlayerRotation = useGameStore((state) => state.updatePlayerRotation);
  const isPaused = useGameStore((state) => state.isPaused);
  const currentWeapon = useGameStore((state) => state.currentWeapon);

  const [, getKeys] = useKeyboardControls();

  const shoot = () => {
    if (!playerRef.current) return;

    const now = Date.now();
    if (now - lastShootTime.current < currentWeapon.fireRate * 1000) return;

    // Calculate bullet spawn position in front of the player
    const bulletPosition = playerRef.current.position.clone();
    bulletPosition.y += 1.5; // Eye level
    
    // Get the direction from the camera
    const direction = new Vector3(0, 0, -1);
    direction.applyQuaternion(playerRef.current.quaternion);
    
    // Position bullet forward from player
    bulletPosition.add(direction.clone().multiplyScalar(1)); // Start bullets 1 unit in front

    const newBullet = {
      id: bulletIdCounter.current++,
      position: bulletPosition,
      direction: direction,
    };

    setBullets((prev) => [...prev, newBullet]);
    lastShootTime.current = now;
  };

  useFrame((state, delta) => {
    if (!playerRef.current || isPaused) return;

    const { forward, backward, left, right, shoot: shooting } = getKeys();
    const velocity = velocityRef.current;

    // Reset velocity
    velocity.set(0, 0, 0);

    // Get camera direction
    const cameraQuaternion = state.camera.quaternion;
    const cameraDirection = new Vector3(0, 0, -1).applyQuaternion(cameraQuaternion);
    const cameraRight = new Vector3(1, 0, 0).applyQuaternion(cameraQuaternion);

    // Calculate movement direction relative to camera
    if (forward) {
      velocity.add(cameraDirection.clone().multiplyScalar(MOVEMENT_SPEED));
    }
    if (backward) {
      velocity.add(cameraDirection.clone().multiplyScalar(-MOVEMENT_SPEED));
    }
    if (left) {
      velocity.add(cameraRight.clone().multiplyScalar(-MOVEMENT_SPEED));
    }
    if (right) {
      velocity.add(cameraRight.clone().multiplyScalar(MOVEMENT_SPEED));
    }

    // Keep movement on ground plane
    velocity.y = 0;

    // Shooting
    if (shooting) {
      shoot();
    }

    // Apply movement
    playerRef.current.position.add(velocity);

    // Update camera
    state.camera.position.copy(playerRef.current.position);
    state.camera.position.y += 1.6; // Eye level

    // Update player rotation to match camera
    playerRef.current.quaternion.copy(new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), Math.atan2(cameraDirection.x, cameraDirection.z)));

    // Update store
    updatePlayerPosition({
      x: playerRef.current.position.x,
      y: playerRef.current.position.y,
      z: playerRef.current.position.z,
    });

    updatePlayerRotation({
      x: playerRef.current.rotation.x,
      y: playerRef.current.rotation.y,
      z: playerRef.current.rotation.z,
    });
  });

  useEffect(() => {
    if (playerRef.current) {
      playerRef.current.position.y = 1;
    }
  }, []);

  const removeBullet = (id: number) => {
    setBullets((prev) => prev.filter((bullet) => bullet.id !== id));
  };

  return (
    <>
      <group ref={playerRef}>
        <mesh>
          <capsuleGeometry args={[0.5, 1, 4, 8]} />
          <meshStandardMaterial color="blue" />
        </mesh>
        <Weapon />
      </group>
      {bullets.map((bullet) => (
        <Bullet
          key={bullet.id}
          position={bullet.position}
          direction={bullet.direction}
          speed={BULLET_SPEED}
          color="#00aaff" // Blue bullets for player
          onHit={() => removeBullet(bullet.id)}
        />
      ))}
    </>
  );
}; 