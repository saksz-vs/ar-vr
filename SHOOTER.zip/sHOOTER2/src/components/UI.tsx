import { useGameStore } from '../store/gameStore';
import { styled } from '@mui/material/styles';
import { Box, Typography, LinearProgress } from '@mui/material';

const UIContainer = styled(Box)({
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  pointerEvents: 'none',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
});

const TopBar = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
});

const HealthBar = styled(LinearProgress)({
  width: '200px',
  height: '20px',
  backgroundColor: '#ff000033',
  '& .MuiLinearProgress-bar': {
    backgroundColor: '#ff0000',
  },
});

const WeaponInfo = styled(Box)({
  position: 'fixed',
  bottom: '20px',
  right: '20px',
  background: 'rgba(0, 0, 0, 0.5)',
  padding: '10px',
  borderRadius: '5px',
  color: 'white',
});

const Crosshair = styled(Box)({
  position: 'fixed',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '20px',
  height: '20px',
  '&::before, &::after': {
    content: '""',
    position: 'absolute',
    background: 'white',
  },
  '&::before': {
    width: '2px',
    height: '100%',
    left: '50%',
    transform: 'translateX(-50%)',
  },
  '&::after': {
    width: '100%',
    height: '2px',
    top: '50%',
    transform: 'translateY(-50%)',
  },
});

export const UI = () => {
  const health = useGameStore((state) => state.player.health);
  const score = useGameStore((state) => state.score);
  const currentWeapon = useGameStore((state) => state.currentWeapon);
  const difficulty = useGameStore((state) => state.difficulty);

  return (
    <UIContainer>
      <TopBar>
        <Box>
          <Typography variant="h6" color="white">
            Health
          </Typography>
          <HealthBar variant="determinate" value={health} />
        </Box>
        <Box>
          <Typography variant="h6" color="white">
            Score: {score}
          </Typography>
          <Typography variant="subtitle1" color="white">
            Difficulty: {difficulty}
          </Typography>
        </Box>
      </TopBar>

      <WeaponInfo>
        <Typography variant="h6">{currentWeapon.name}</Typography>
        <Typography>
          Ammo: {currentWeapon.ammo}/{currentWeapon.maxAmmo}
        </Typography>
      </WeaponInfo>

      <Crosshair />
    </UIContainer>
  );
}; 