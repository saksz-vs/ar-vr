import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Vector3, Group } from 'three';

interface WeaponProps {
  position?: Vector3;
}

export const Weapon = ({ position = new Vector3(0.4, -0.5, -1) }: WeaponProps) => {
  const weaponRef = useRef<Group>(null);

  useFrame((state) => {
    if (!weaponRef.current) return;

    // Add slight weapon sway
    const time = state.clock.getElapsedTime();
    weaponRef.current.position.y = position.y + Math.sin(time * 2) * 0.005;
    weaponRef.current.rotation.z = Math.sin(time * 2) * 0.01;
  });

  return (
    <group ref={weaponRef} position={position}>
      {/* Gun body */}
      <mesh castShadow>
        <boxGeometry args={[0.1, 0.1, 0.4]} />
        <meshStandardMaterial color="#333333" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Gun barrel */}
      <mesh position={[0, 0.05, 0.2]} castShadow>
        <cylinderGeometry args={[0.02, 0.02, 0.4]} />
        <meshStandardMaterial color="#222222" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Gun grip */}
      <mesh position={[0, -0.15, 0]} castShadow>
        <boxGeometry args={[0.08, 0.2, 0.1]} />
        <meshStandardMaterial color="#444444" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Gun sight */}
      <mesh position={[0, 0.08, 0]} castShadow>
        <boxGeometry args={[0.02, 0.04, 0.02]} />
        <meshStandardMaterial color="#222222" metalness={0.9} roughness={0.1} />
      </mesh>
    </group>
  );
}; 