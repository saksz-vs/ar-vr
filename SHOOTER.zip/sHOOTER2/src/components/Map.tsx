import { useEffect, useRef, useState } from 'react';
import { useLoader } from '@react-three/fiber';
import { TextureLoader, Vector3 } from 'three';
import { MapConfig } from '../types/game';
import { Enemy } from './Enemy';
import { useGameStore } from '../store/gameStore';

interface MapProps {
  config: MapConfig;
}

const getRandomPosition = () => {
  return new Vector3(
    (Math.random() - 0.5) * 80, // Random X position between -40 and 40
    1,
    (Math.random() * -30) - 10 // Random Z position between -40 and -10
  );
};

export const Map = ({ config }: MapProps) => {
  const floorTexture = useLoader(TextureLoader, config.textureUrl);
  const [enemies, setEnemies] = useState<{ id: number; position: Vector3 }[]>([]);
  const enemyIdCounter = useRef(0);
  const addScore = useGameStore((state) => state.addScore);
  const difficulty = useGameStore((state) => state.difficulty);
  
  // Get required enemy count based on difficulty
  const requiredEnemyCount = {
    easy: 3,
    medium: 5,
    hard: 7,
  }[difficulty];

  // Force respawn all enemies when difficulty changes
  useEffect(() => {
    if (floorTexture) {
      floorTexture.wrapS = floorTexture.wrapT = 1000;
      floorTexture.repeat.set(5, 5);
    }

    // Reset enemy counter when difficulty changes
    enemyIdCounter.current = 0;
    
    // Initial enemy spawn with evenly spaced positions
    const initialEnemies = Array.from({ length: requiredEnemyCount }, (_, i) => ({
      id: enemyIdCounter.current++,
      position: new Vector3(
        (i - requiredEnemyCount / 2) * 8,  // Space enemies evenly
        1,                                  // Keep them at ground level
        -20                                 // Put them ahead of the player
      ),
    }));

    setEnemies(initialEnemies);
    
    console.log(`Spawned ${initialEnemies.length} enemies for ${difficulty} difficulty`);
  }, [difficulty, requiredEnemyCount]);

  const handleEnemyHit = (enemyId: number) => {
    setEnemies(prev => {
      // Remove the hit enemy
      const remainingEnemies = prev.filter(enemy => enemy.id !== enemyId);
      
      // Spawn a new enemy to maintain count
      const newEnemy = {
        id: enemyIdCounter.current++,
        position: getRandomPosition(),
      };

      addScore(100); // Add score for the kill
      
      const updatedEnemies = [...remainingEnemies, newEnemy];
      console.log(`Enemy hit! Current count: ${updatedEnemies.length}`);
      
      return updatedEnemies;
    });
  };

  return (
    <group>
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial map={floorTexture} />
      </mesh>

      {/* Walls */}
      <mesh position={[0, 2.5, -50]} receiveShadow>
        <boxGeometry args={[100, 5, 1]} />
        <meshStandardMaterial color="gray" />
      </mesh>
      <mesh position={[0, 2.5, 50]} receiveShadow>
        <boxGeometry args={[100, 5, 1]} />
        <meshStandardMaterial color="gray" />
      </mesh>
      <mesh position={[-50, 2.5, 0]} receiveShadow>
        <boxGeometry args={[1, 5, 100]} />
        <meshStandardMaterial color="gray" />
      </mesh>
      <mesh position={[50, 2.5, 0]} receiveShadow>
        <boxGeometry args={[1, 5, 100]} />
        <meshStandardMaterial color="gray" />
      </mesh>

      {/* Obstacles */}
      {config.obstacles.map((obstacle, index) => (
        <mesh
          key={index}
          position={[obstacle.position.x, obstacle.position.y, obstacle.position.z]}
          rotation={[obstacle.rotation.x, obstacle.rotation.y, obstacle.rotation.z]}
          scale={[obstacle.scale.x, obstacle.scale.y, obstacle.scale.z]}
          castShadow
          receiveShadow
        >
          <boxGeometry />
          <meshStandardMaterial color="#444" />
        </mesh>
      ))}

      {/* Enemies */}
      {enemies.map((enemy) => (
        <Enemy
          key={enemy.id}
          id={enemy.id}
          position={enemy.position}
          onHit={() => handleEnemyHit(enemy.id)}
        />
      ))}
    </group>
  );
}; 