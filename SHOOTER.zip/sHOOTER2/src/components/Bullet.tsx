import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Vector3, Mesh } from 'three';
import { Trail, PointMaterial } from '@react-three/drei';

interface BulletProps {
  position: Vector3;
  direction: Vector3;
  speed?: number;
  color?: string;
  onHit?: () => void;
}

export const Bullet = ({ 
  position, 
  direction, 
  speed = 1, 
  color = "#ffff00", 
  onHit 
}: BulletProps) => {
  const bulletRef = useRef<Mesh>(null);
  const velocity = useRef(direction.normalize().multiplyScalar(speed));
  const lifeTime = useRef(0);

  useFrame((state, delta) => {
    if (!bulletRef.current) return;

    // Update position
    bulletRef.current.position.add(velocity.current);

    // Update lifetime
    lifeTime.current += delta;
    if (lifeTime.current > 3) {
      onHit?.();
    }
  });

  return (
    <mesh ref={bulletRef} position={position}>
      <Trail
        width={1}
        length={10}
        color={color}
        attenuation={(t) => (1 - t)}
      />
      <pointLight 
        intensity={1.5} 
        distance={2} 
        color={color} 
      />
      <sphereGeometry args={[0.2, 16, 16]} />
      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={3}
        toneMapped={false}
      />
    </mesh>
  );
}; 