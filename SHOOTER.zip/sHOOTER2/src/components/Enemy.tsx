import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Vector3, AnimationMixer, Group, Object3D, MeshStandardMaterial, LoopRepeat } from 'three';
import { useFBX, useAnimations } from '@react-three/drei';
import { useGameStore } from '../store/gameStore';
import { Bullet } from './Bullet';

interface EnemyProps {
  position: Vector3;
  onHit: () => void;
  id: number;
}

const STRAFE_SPEED = 0.05;
const SHOOT_INTERVAL = 2000;
const BULLET_SPEED = 0.6;

const ENEMY_COLORS = {
  easy: '#ff0000',
  medium: '#ffff00',
  hard: '#800080',
};

const maxActiveShooters = 2;
const activeShooters = new Set<number>();

export const Enemy = ({ position, onHit, id }: EnemyProps) => {
  const enemyRef = useRef<Group>(null);
  const [bullets, setBullets] = useState<{ id: number; position: Vector3; direction: Vector3 }[]>([]);
  const bulletIdCounter = useRef(0);
  const lastShootTime = useRef(0);
  const strafeDirection = useRef(1);
  const initialX = useRef(position.x);
  const shootDecisionTime = useRef(0);
  const isActiveShooter = useRef(false);
  const mixer = useRef<AnimationMixer | null>(null);

  // Load models and animations
  const fbx = useFBX('/enemy.fbx');
  const { animations: positionAnimations } = useFBX('/position.fbx');
  const { animations: strafeAnimations } = useFBX('/Strafe.fbx');
  
  const difficulty = useGameStore((state) => state.difficulty);
  const { actions } = useAnimations(
    difficulty === 'easy' ? positionAnimations : strafeAnimations,
    enemyRef
  );

  const playerPosition = useGameStore((state) => state.player.position);
  const takeDamage = useGameStore((state) => state.takeDamage);

  // Set up model and animations
  useEffect(() => {
    if (!fbx) return;

    // Configure model
    fbx.scale.set(0.02, 0.02, 0.02);
    fbx.traverse((child: Object3D) => {
      // Type guard for checking if the object is a Mesh with material
      if ('isMesh' in child && child.isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
  
        // Check if the child has a material property
        if ('material' in child) {
          // Handle both single and array materials
          const materials = Array.isArray(child.material) ? child.material : [child.material];
          
          // Apply color to each material if it's a MeshStandardMaterial
          materials.forEach(mat => {
            if (mat instanceof MeshStandardMaterial) {
              mat.color.set(ENEMY_COLORS[difficulty]);
              mat.emissive.set(ENEMY_COLORS[difficulty]);
              mat.emissiveIntensity = 0.2;
            }
          });
        }
      }
    });

    // Play appropriate animation based on difficulty
    if (actions) {
      // Stop all current actions
      Object.values(actions).forEach(action => action?.stop());
      
      // Play the first available animation for the current difficulty
      const actionNames = Object.keys(actions);
      if (actionNames.length > 0) {
        const actionToPlay = actions[actionNames[0]];
        if (actionToPlay) {
          actionToPlay.play();
          
          // For strafing animation, make it loop
          if (difficulty !== 'easy') {
            actionToPlay.setLoop(LoopRepeat, Infinity);
          }
        }
      }
    }
  }, [fbx, difficulty, actions]);

  // Animation mixer update
  useFrame((state, delta) => {
    if (mixer.current) {
      mixer.current.update(delta);
    }

    if (!enemyRef.current) return;

    // Movement based on difficulty
    if (difficulty !== 'easy') {
      const newX = enemyRef.current.position.x + (STRAFE_SPEED * strafeDirection.current);
      
      // Reverse direction if moved too far from initial position
      if (Math.abs(newX - initialX.current) > 5) {
        strafeDirection.current *= -1;
      }
      
      enemyRef.current.position.x = newX;
    }

    // Shooting logic for hard difficulty
    if (difficulty === 'hard') {
      const now = Date.now();
      
      if (now - shootDecisionTime.current > 3000) {
        const shouldBeShooter = Math.random() < 0.3;
        
        if (isActiveShooter.current) {
          activeShooters.delete(id);
          isActiveShooter.current = false;
        }
        
        if (shouldBeShooter && activeShooters.size < maxActiveShooters) {
          activeShooters.add(id);
          isActiveShooter.current = true;
        }
        
        shootDecisionTime.current = now;
      }
      
      if (isActiveShooter.current && now - lastShootTime.current > SHOOT_INTERVAL) {
        // Safe check for enemyRef.current
        if (enemyRef.current) {
          const direction = new Vector3()
            .subVectors(
              new Vector3(playerPosition.x, playerPosition.y, playerPosition.z), 
              enemyRef.current.position
            )
            .normalize();

          // The non-null assertion operator (!) tells TypeScript that
          // enemyRef.current is definitely not null at this point
          const enemyPosition = enemyRef.current!.position.clone().add(new Vector3(0, 1, 0));
          
          setBullets(prev => [...prev, {
            id: bulletIdCounter.current++,
            position: enemyPosition,
            direction: direction,
          }]);
          lastShootTime.current = now;
        }
      }
    }
  });

  const removeBullet = (id: number) => {
    setBullets(prev => prev.filter(bullet => bullet.id !== id));
  };

  useEffect(() => {
    return () => {
      if (isActiveShooter.current) {
        activeShooters.delete(id);
      }
    };
  }, [id]);

  return (
    <>
      <group ref={enemyRef} position={position} onClick={onHit}>
        <primitive object={fbx} />
      </group>
      {bullets.map(bullet => (
        <Bullet
          key={bullet.id}
          position={bullet.position}
          direction={bullet.direction}
          speed={BULLET_SPEED}
          color="#ff0000"
          onHit={() => {
            removeBullet(bullet.id);
            takeDamage(10);
          }}
        />
      ))}
    </>
  );
};