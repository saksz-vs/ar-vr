import { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { KeyboardControls, PointerLockControls, Environment } from '@react-three/drei';
import { Physics } from '@react-three/cannon';
import { Player } from './Player';
import { Map } from './Map';
import { UI } from './UI';
import { MAPS } from '../config/maps';
import { useGameStore } from '../store/gameStore';

const keyboardMap = [
  { name: 'forward', keys: ['KeyW'] },
  { name: 'backward', keys: ['KeyS'] },
  { name: 'left', keys: ['KeyA'] },
  { name: 'right', keys: ['KeyD'] },
  { name: 'jump', keys: ['Space'] },
  { name: 'shoot', keys: ['Mouse0'] }, // Left mouse button
];

const environmentPresets: Record<string, "sunset" | "dawn" | "night"> = {
  easy: 'sunset',    // Urban environment
  medium: 'dawn',    // Desert environment
  hard: 'night',     // Forest environment
};

export const Game = () => {
  const difficulty = useGameStore((state) => state.difficulty);
  const isPaused = useGameStore((state) => state.isPaused);
  const togglePause = useGameStore((state) => state.togglePause);

  // Select map based on difficulty
  const mapIndex = {
    easy: 0,
    medium: 1,
    hard: 2,
  }[difficulty];
  const currentMap = MAPS[mapIndex];

  return (
    <KeyboardControls map={keyboardMap}>
      <Canvas
        shadows
        camera={{ fov: 75, near: 0.1, far: 1000 }}
        style={{ position: 'absolute' }}
      >
        <Environment preset={environmentPresets[difficulty]} background />
        <ambientLight intensity={0.3} />
        <pointLight position={[10, 10, 10]} intensity={1} castShadow />
        <Suspense fallback={null}>
          <Physics gravity={[0, -30, 0]}>
            <Player />
            <Map config={currentMap} />
            <PointerLockControls />
          </Physics>
        </Suspense>
      </Canvas>
      <UI />
    </KeyboardControls>
  );
}; 