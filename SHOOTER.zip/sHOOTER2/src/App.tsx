import { useState } from 'react'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { CssBaseline, Box, Button, Typography, Container } from '@mui/material'
import { Game } from './components/Game'
import { useGameStore } from './store/gameStore'

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
})

const MenuScreen = ({
  onStart,
  onDifficultySelect,
}: {
  onStart: () => void;
  onDifficultySelect: (difficulty: 'Easy' | 'Medium' | 'Hard') => void;
}) => {
  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          mt: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 3,
        }}
      >
        <Typography variant="h2" component="h1" gutterBottom>
          FPS Game
        </Typography>
        <Typography variant="h5" gutterBottom>
          Select Difficulty
        </Typography>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => {
              onDifficultySelect('easy');
              onStart();
            }}
          >
            Easy
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={() => {
              onDifficultySelect('medium');
              onStart();
            }}
          >
            Medium
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={() => {
              onDifficultySelect('hard');
              onStart();
            }}
          >
            Hard
          </Button>
        </Box>
      </Box>
    </Container>
  )
}

const GameOverScreen = ({
  score,
  onRestart,
}: {
  score: number;
  onRestart: () => void;
}) => {
  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          mt: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 3,
        }}
      >
        <Typography variant="h2" component="h1" gutterBottom>
          Game Over
        </Typography>
        <Typography variant="h4" gutterBottom>
          Score: {score}
        </Typography>
        <Button variant="contained" color="primary" onClick={onRestart}>
          Play Again
        </Button>
      </Box>
    </Container>
  )
}

function App() {
  const [gameStarted, setGameStarted] = useState(false)
  const initGame = useGameStore((state) => state.initGame)
  const resetGame = useGameStore((state) => state.resetGame)
  const isGameOver = useGameStore((state) => state.isGameOver)
  const score = useGameStore((state) => state.score)

  const handleStart = () => {
    setGameStarted(true)
  }

  const handleRestart = () => {
    resetGame()
    setGameStarted(false)
  }

  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      {!gameStarted ? (
        <MenuScreen onStart={handleStart} onDifficultySelect={initGame} />
      ) : isGameOver ? (
        <GameOverScreen score={score} onRestart={handleRestart} />
      ) : (
        <Game />
      )}
    </ThemeProvider>
  )
}

export default App
