export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Player {
  position: Vector3;
  rotation: Vector3;
  health: number;
  score: number;
}

export interface Weapon {
  id: string;
  name: string;
  damage: number;
  fireRate: number;
  reloadTime: number;
  ammo: number;
  maxAmmo: number;
}

export interface GameState {
  difficulty: 'easy' | 'medium' | 'hard';
  player: Player;
  currentWeapon: Weapon;
  score: number;
  enemies: Player[];
  isGameOver: boolean;
  isPaused: boolean;
}

export interface MapConfig {
  id: string;
  name: string;
  textureUrl: string;
  spawnPoints: Vector3[];
  obstacles: {
    position: Vector3;
    scale: Vector3;
    rotation: Vector3;
  }[];
} 