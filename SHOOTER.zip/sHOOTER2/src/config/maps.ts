import { MapConfig } from '../types/game';

export const MAPS: MapConfig[] = [
  {
    id: 'urban',
    name: 'Urban Warfare',
    textureUrl: '/31129.jpg',
    spawnPoints: [
      { x: 0, y: 1, z: 0 },
      { x: 10, y: 1, z: 10 },
      { x: -10, y: 1, z: -10 },
    ],
    obstacles: [
      {
        position: { x: 5, y: 2, z: 5 },
        scale: { x: 2, y: 4, z: 2 },
        rotation: { x: 0, y: 0, z: 0 },
      },
      {
        position: { x: -5, y: 2, z: -5 },
        scale: { x: 3, y: 3, z: 3 },
        rotation: { x: 0, y: Math.PI / 4, z: 0 },
      },
    ],
  },
  {
    id: 'desert',
    name: 'Desert Storm',
    textureUrl: '/31129.jpg',
    spawnPoints: [
      { x: 0, y: 1, z: 0 },
      { x: 15, y: 1, z: 15 },
      { x: -15, y: 1, z: -15 },
    ],
    obstacles: [
      {
        position: { x: 7, y: 3, z: 7 },
        scale: { x: 4, y: 6, z: 4 },
        rotation: { x: 0, y: 0, z: 0 },
      },
      {
        position: { x: -7, y: 2, z: -7 },
        scale: { x: 2, y: 4, z: 2 },
        rotation: { x: 0, y: Math.PI / 3, z: 0 },
      },
    ],
  },
  {
    id: 'forest',
    name: 'Forest Assault',
    textureUrl: '/31129.jpg',
    spawnPoints: [
      { x: 0, y: 1, z: 0 },
      { x: 20, y: 1, z: 20 },
      { x: -20, y: 1, z: -20 },
    ],
    obstacles: [
      {
        position: { x: 10, y: 4, z: 10 },
        scale: { x: 5, y: 8, z: 5 },
        rotation: { x: 0, y: Math.PI / 6, z: 0 },
      },
      {
        position: { x: -10, y: 3, z: -10 },
        scale: { x: 3, y: 6, z: 3 },
        rotation: { x: 0, y: Math.PI / 2, z: 0 },
      },
    ],
  },
]; 