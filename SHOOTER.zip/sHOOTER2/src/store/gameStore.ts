import { create } from 'zustand';
import { GameState, Weapon, Vector3 } from '../types/game';

const DEFAULT_WEAPONS: Weapon[] = [
  {
    id: 'pistol',
    name: 'Pistol',
    damage: 20,
    fireRate: 0.5,
    reloadTime: 1,
    ammo: 12,
    maxAmmo: 12,
  },
  {
    id: 'rifle',
    name: 'Rifle',
    damage: 35,
    fireRate: 0.3,
    reloadTime: 2,
    ammo: 30,
    maxAmmo: 30,
  },
  {
    id: 'shotgun',
    name: 'Shotgun',
    damage: 80,
    fireRate: 1,
    reloadTime: 2.5,
    ammo: 6,
    maxAmmo: 6,
  },
];

interface GameStore extends GameState {
  initGame: (difficulty: 'easy' | 'medium' | 'hard') => void;
  updatePlayerPosition: (position: Vector3) => void;
  updatePlayerRotation: (rotation: Vector3) => void;
  takeDamage: (amount: number) => void;
  addScore: (points: number) => void;
  switchWeapon: (weaponId: string) => void;
  togglePause: () => void;
  resetGame: () => void;
}

export const useGameStore = create<GameStore>((set) => ({
  difficulty: 'medium',
  player: {
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    health: 100,
    score: 0,
  },
  currentWeapon: DEFAULT_WEAPONS[0],
  score: 0,
  enemies: [],
  isGameOver: false,
  isPaused: false,

  initGame: (difficulty) =>
    set((state) => ({
      ...state,
      difficulty,
      player: {
        ...state.player,
        health: 100,
        score: 0,
      },
      currentWeapon: DEFAULT_WEAPONS[0],
      score: 0,
      isGameOver: false,
      isPaused: false,
    })),

  updatePlayerPosition: (position) =>
    set((state) => ({
      ...state,
      player: {
        ...state.player,
        position,
      },
    })),

  updatePlayerRotation: (rotation) =>
    set((state) => ({
      ...state,
      player: {
        ...state.player,
        rotation,
      },
    })),

  takeDamage: (amount) =>
    set((state) => {
      const newHealth = Math.max(0, state.player.health - amount);
      return {
        ...state,
        player: {
          ...state.player,
          health: newHealth,
        },
        isGameOver: newHealth <= 0,
      };
    }),

  addScore: (points) =>
    set((state) => ({
      ...state,
      score: state.score + points,
      player: {
        ...state.player,
        score: state.player.score + points,
      },
    })),

  switchWeapon: (weaponId) =>
    set((state) => ({
      ...state,
      currentWeapon:
        DEFAULT_WEAPONS.find((w) => w.id === weaponId) || state.currentWeapon,
    })),

  togglePause: () =>
    set((state) => ({
      ...state,
      isPaused: !state.isPaused,
    })),

  resetGame: () =>
    set((state) => ({
      ...state,
      player: {
        position: { x: 0, y: 1, z: 0 },
        rotation: { x: 0, y: 0, z: 0 },
        health: 100,
        score: 0,
      },
      currentWeapon: DEFAULT_WEAPONS[0],
      score: 0,
      isGameOver: false,
      isPaused: false,
    })),
})); 