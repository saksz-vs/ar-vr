# FPS Game

A simple browser-based First Person Shooter game built with React, Three.js, and TypeScript.

## Features

- Three difficulty levels (Easy, Medium, Hard)
- Three unique maps with different layouts
- Three weapons with different characteristics
- Modern UI with health, score, and weapon display
- Smooth movement and camera controls
- Physics-based collision detection

## Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)

## Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```
3. Start the development server:
```bash
npm run dev
```
4. Open your browser and navigate to `http://localhost:5173`

## Controls

- WASD / Arrow Keys: Movement
- Mouse: Look around
- F: Shoot
- Space: Jump
- Esc: Pause game

## Game Mechanics

- Choose your difficulty level at the start
- Navigate through the map and shoot enemies
- Collect points by defeating enemies
- Manage your health and ammo
- Game ends when player health reaches zero

## Development

This project uses:
- Vite for build tooling
- React for UI components
- Three.js for 3D rendering
- @react-three/fiber for React Three.js bindings
- @react-three/drei for useful Three.js helpers
- @react-three/cannon for physics
- Material-UI for UI components
- Zustand for state management

## License

MIT
